﻿<#
    Network Priority Manager
    ------------------------
    Sets the Windows Interface Metric for your physical network adapters by
    drag-and-drop. Top row = highest priority = default internet route.
#>

# ===================== 0) Base assemblies + error reporting =====================
try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    Add-Type -AssemblyName System.Drawing -ErrorAction Stop
} catch {
    try {
        "$(Get-Date) - Failed to load base assemblies: $($_.Exception.Message)" |
            Out-File -FilePath (Join-Path $env:TEMP "NetworkSuite_fatal.log") -Encoding UTF8
    } catch {}
    exit 1
}

$LogFile = Join-Path $env:TEMP "NetworkSuite_error.log"

function Write-AppLog {
    param([string]$Message)
    try { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message" | Add-Content -Path $LogFile -Encoding UTF8 } catch {}
}

function Show-FatalError {
    param([string]$Title, [string]$Message, $ErrorRecord = $null)
    Write-AppLog "$Title :: $Message"
    if ($ErrorRecord) {
        try {
            Write-AppLog ("  Line   : " + $ErrorRecord.InvocationInfo.ScriptLineNumber)
            Write-AppLog ("  Command: " + ($ErrorRecord.InvocationInfo.Line).Trim())
            Write-AppLog ("  Stack  : " + $ErrorRecord.ScriptStackTrace)
            Write-AppLog ("  Detail : " + $ErrorRecord.Exception.ToString())
            $Message = "$Message`n`n(line " + $ErrorRecord.InvocationInfo.ScriptLineNumber + ": " + ($ErrorRecord.InvocationInfo.Line).Trim() + ")"
        } catch {}
    }
    try {
        [System.Windows.Forms.MessageBox]::Show(
            "$Message`n`nMore details were saved to this file:`n$LogFile",
            "Network Priority Manager - $Title",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    } catch {}
}

try { Unblock-File -Path $PSCommandPath -ErrorAction SilentlyContinue } catch {}

# ===================== 1) Windows networking module check =====================
try {
    if (-not (Get-Command Get-NetAdapter -ErrorAction SilentlyContinue)) {
        Show-FatalError "Error" "The NetAdapter module was not found on this system.`nThis app requires Windows 8 / Server 2012 or newer."
        exit 1
    }
} catch {
    Show-FatalError "System check error" $_.Exception.Message
    exit 1
}

# ===================== 2) Self-Elevation (Admin) + STA =====================
try {
    $IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $IsSTA   = [System.Threading.Thread]::CurrentThread.GetApartmentState() -eq [System.Threading.ApartmentState]::STA
    if (-not $IsAdmin -or -not $IsSTA) {
        if (-not $PSCommandPath) {
            Show-FatalError "Error" "Could not find the script file path. Please run the file directly."
            exit 1
        }
        Start-Process -FilePath "powershell.exe" `
            -ArgumentList @("-NoProfile","-STA","-ExecutionPolicy","Bypass","-File","`"$PSCommandPath`"") `
            -Verb RunAs -ErrorAction Stop
        exit 0
    }
} catch {
    Show-FatalError "Administrator access not confirmed" "You must accept the UAC prompt to run this app.`n`nTechnical error: $($_.Exception.Message)"
    exit 1
}

# ===================== 3) WPF =====================
try {
    Add-Type -AssemblyName PresentationFramework -ErrorAction Stop
    Add-Type -AssemblyName PresentationCore -ErrorAction Stop
    Add-Type -AssemblyName WindowsBase -ErrorAction Stop
} catch {
    Show-FatalError "Error loading the GUI" $_.Exception.Message
    exit 1
}

try {

# ===================== Paths =====================
$ScriptDir  = Split-Path -Parent $PSCommandPath
$IconFile   = Join-Path $ScriptDir "icon.ico"
$ConfigDir  = Join-Path $env:APPDATA "NetworkSuite"
$BackupFile = Join-Path $ConfigDir "backup.json"
$OrderFile  = Join-Path $ConfigDir "order.json"
$PlanFile   = Join-Path $ConfigDir "plan.json"
$PersistPs1 = Join-Path $ConfigDir "NetworkSuite-Persist.ps1"
$TaskName   = "NetworkSuite Persist Metrics"
if (-not (Test-Path $ConfigDir)) { New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null }

# Automatic migration from the previous separate app's settings (if present)
try {
    $oldNpm = Join-Path $env:APPDATA "NetPriorityManager"
    foreach ($f in @("backup.json","order.json")) {
        $src = Join-Path $oldNpm $f
        $dst = Join-Path $ConfigDir $f
        if ((Test-Path $src) -and -not (Test-Path $dst)) { Copy-Item $src $dst -Force }
    }
} catch { Write-AppLog "Migration: $($_.Exception.Message)" }

# ===================== UI text (English + Persian) =====================
$LangFile = Join-Path $ConfigDir "lang.txt"
$script:Lang = "EN"
try {
    if (Test-Path $LangFile) {
        $saved = (Get-Content $LangFile -ErrorAction SilentlyContinue | Select-Object -First 1)
        if ($saved) { $saved = $saved.Trim().ToUpper() }
        if ($saved -eq "FA" -or $saved -eq "EN") { $script:Lang = $saved }
    }
} catch { Write-AppLog "Lang load: $($_.Exception.Message)" }

$script:L = @{

EN = @{
    AppTitle    = "Network Priority Manager"
    HeaderSub   = "Adapter priority (Interface Metric)"
    Subtitle    = "Higher row = higher priority. Drag and drop rows to reorder."
    Apply       = "Apply"
    Refresh     = "Refresh"
    Restore     = "Restore previous settings"
    Tray        = "Minimize to tray"
    StatusUp    = "Connected"
    StatusDown  = "Disconnected"
    StatusOff   = "Disabled"
    NotFound    = "Not found"
    Ready       = "Ready. Reorder the adapters and click Apply."
    Refreshed   = "Adapter list refreshed."
    Applied     = "Priorities applied successfully."
    ApplyErr    = "Some items were not applied:"
    NoBackup    = "No backup found to restore."
    Restored    = "Previous settings restored successfully."
    RestoreErr  = "Restore failed:"
    ErrApply    = "Failed to apply settings:"
    ErrRestore  = "Failed to restore:"
    ErrTitle    = "Error"
    NewAdapter  = "New adapter detected:"
    NewAdapterT = "Move it in the list and click Apply to set its priority."
    TrayShow    = "Show app"
    TrayExit    = "Exit"
    TrayRunning = "The app is running in the tray."
    Help        = "Help"
    HelpTitle   = "Help & User Guide"
    HelpSub     = "Everything you need, grouped by topic"
    HelpOk      = "Got it"
    About       = "About"
    AboutSub    = "Network Priority Manager"
    LangBtn     = "FA"
    LangTip     = "Switch to Persian"
    LangChanged = "Language changed to English."
    Metric      = "Metric:"
    Persist     = "Keep after restart"
    PersistOn   = "Persist: ON"
    PersistOff  = "Persist: OFF"
    PersistTip  = "Re-applies your metrics automatically after every Windows restart, so Windows cannot switch them back to Automatic."
    PersistEn   = "Keep after restart is ON - your priorities will be re-applied at every boot."
    PersistDis  = "Keep after restart is OFF - Windows may reset the metrics after a restart."
    PersistErr  = "Could not change the startup task:"
    AboutText   = @"
Network Priority Manager

Made by A1iRoX with the help of AI.

A small Windows tool that lets you decide which network adapter your PC uses
first, by simply dragging rows into the order you want.

Follow my Telegram channel for updates and new tools.

If you enjoyed this app, I'd really appreciate your support. Donation link below.
"@
    HelpText    = @"
Drag and drop your adapters, then click Apply. The top row gets the lowest
interface metric = highest priority = default internet route.
"@
}

FA = @{
    AppTitle    = "مدیریت اولویت شبکه"
    HeaderSub   = "اولویت کارت شبکه (Interface Metric)"
    Subtitle    = "هر ردیف بالاتر = اولویت بیشتر. برای جابجایی، ردیف‌ها را بکشید و رها کنید."
    Apply       = "اعمال"
    Refresh     = "بازخوانی"
    Restore     = "بازگردانی تنظیمات قبلی"
    Tray        = "کوچک کردن به تری"
    StatusUp    = "متصل"
    StatusDown  = "قطع"
    StatusOff   = "غیرفعال"
    NotFound    = "یافت نشد"
    Ready       = "آماده است. ترتیب کارت‌ها را تغییر دهید و اعمال را بزنید."
    Refreshed   = "لیست کارت‌های شبکه بازخوانی شد."
    Applied     = "اولویت‌ها با موفقیت اعمال شد."
    ApplyErr    = "برخی موارد اعمال نشد:"
    NoBackup    = "نسخه پشتیبانی برای بازگردانی پیدا نشد."
    Restored    = "تنظیمات قبلی با موفقیت بازگردانی شد."
    RestoreErr  = "بازگردانی انجام نشد:"
    ErrApply    = "اعمال تنظیمات ناموفق بود:"
    ErrRestore  = "بازگردانی ناموفق بود:"
    ErrTitle    = "خطا"
    NewAdapter  = "کارت شبکه جدید شناسایی شد:"
    NewAdapterT = "جای آن را در لیست تعیین کنید و اعمال را بزنید."
    TrayShow    = "نمایش برنامه"
    TrayExit    = "خروج"
    TrayRunning = "برنامه در تری در حال اجراست."
    Help        = "راهنما"
    HelpTitle   = "راهنمای استفاده"
    HelpSub     = "هر چیزی که لازم دارید، دسته‌بندی شده"
    HelpOk      = "متوجه شدم"
    About       = "درباره"
    AboutSub    = "مدیریت اولویت شبکه"
    LangBtn     = "EN"
    LangTip     = "تغییر به انگلیسی"
    LangChanged = "زبان به فارسی تغییر کرد."
    Metric      = "متریک:"
    Persist     = "حفظ بعد از ریست"
    PersistOn   = "حفظ ریست: روشن"
    PersistOff  = "حفظ ریست: خاموش"
    PersistTip  = "بعد از هر بار ریست ویندوز، متریک‌ها را دوباره خودکار اعمال می‌کند تا ویندوز آن‌ها را به حالت اتوماتیک برنگرداند."
    PersistEn   = "حفظ بعد از ریست روشن شد؛ اولویت‌ها بعد از هر بوت دوباره اعمال می‌شوند."
    PersistDis  = "حفظ بعد از ریست خاموش شد؛ ممکن است ویندوز بعد از ریست متریک‌ها را عوض کند."
    PersistErr  = "تغییر تسک استارتاپ ناموفق بود:"
    AboutText   = @"
مدیریت اولویت شبکه

ساخته شده توسط A1iRoX به کمک هوش مصنوعی.

یک ابزار کوچک ویندوزی که به شما اجازه می‌دهد تعیین کنید کامپیوتر ابتدا از کدام
کارت شبکه استفاده کند؛ فقط با کشیدن ردیف‌ها به ترتیب دلخواه.

برای آگاهی از نسخه‌های جدید و ابزارهای بعدی، کانال تلگرام من را دنبال کنید.

اگه از برنامه خوشتون اومد، ممنون می‌شم حمایتم کنید. لینک دونیت پایین همین صفحه.
"@
    HelpText    = @"
کارت‌های شبکه را بکشید و جابجا کنید و سپس اعمال را بزنید. ردیف اول کمترین
متریک را می‌گیرد؛ یعنی بالاترین اولویت و مسیر پیش‌فرض اینترنت.
"@
}

}

function T([string]$key) {
    $table = $script:L[$script:Lang]
    if ($table -and $null -ne $table[$key]) { return $table[$key] }
    return $script:L["EN"][$key]
}
function Is-RTL { return ($script:Lang -eq "FA") }

function Get-StatusText([string]$raw) {
    switch ($raw) {
        "Up"           { return (T "StatusUp") }
        "Disconnected" { return (T "StatusDown") }
        "Disabled"     { return (T "StatusOff") }
        "NotFound"     { return (T "NotFound") }
        default        { return $raw }
    }
}

# ===================== Adapters =====================
function Get-AdapterSnapshot {
    $adapters = Get-NetAdapter -Physical -ErrorAction SilentlyContinue
    if (-not $adapters) { $adapters = Get-NetAdapter -ErrorAction SilentlyContinue }

    $list = @()
    foreach ($a in $adapters) {
        if ($a.Virtual) { continue }
        $v4 = Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
        $v6 = Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue
        $list += [PSCustomObject]@{
            IfIndex      = $a.ifIndex
            Name         = $a.Name
            Description  = $a.InterfaceDescription
            Status       = (Get-StatusText ([string]$a.Status))
            RawStatus    = $a.Status
            MetricV4     = if ($v4) { $v4.InterfaceMetric } else { $null }
            AutoMetricV4 = if ($v4) { $v4.AutomaticMetric } else { $null }
            MetricV6     = if ($v6) { $v6.InterfaceMetric } else { $null }
            AutoMetricV6 = if ($v6) { $v6.AutomaticMetric } else { $null }
            HasV6        = [bool]$v6
        }
    }
    return ,$list
}

# ===================== XAML =====================
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:shell="clr-namespace:System.Windows.Shell;assembly=PresentationFramework"
        Title="Network Priority Manager" Height="680" Width="720"
        MinHeight="520" MinWidth="640"
        WindowStartupLocation="CenterScreen"
        WindowStyle="None" ResizeMode="CanResize"
        FontFamily="Segoe UI" FontSize="13"
        FlowDirection="LeftToRight"
        Background="#07070A" Topmost="True">

    <shell:WindowChrome.WindowChrome>
        <shell:WindowChrome CaptionHeight="0" ResizeBorderThickness="6"
                            GlassFrameThickness="0" CornerRadius="0" UseAeroCaptionButtons="False"/>
    </shell:WindowChrome.WindowChrome>

    <Window.Resources>
        <SolidColorBrush x:Key="Surface"     Color="#111114"/>
        <SolidColorBrush x:Key="SurfaceAlt"  Color="#18181D"/>
        <SolidColorBrush x:Key="Stroke"      Color="#2A2A31"/>
        <SolidColorBrush x:Key="Text"        Color="#F6F6F8"/>
        <SolidColorBrush x:Key="Muted"       Color="#A7A7B2"/>
        <SolidColorBrush x:Key="Accent"      Color="#F97316"/>
        <SolidColorBrush x:Key="AccentDim"   Color="#C2410F"/>
        <SolidColorBrush x:Key="AccentSoft"  Color="#2A150D"/>
        <SolidColorBrush x:Key="Ok"          Color="#FB923C"/>
        <SolidColorBrush x:Key="Bad"         Color="#6E6E78"/>
        <SolidColorBrush x:Key="LinkUp"      Color="#22C55E"/>
        <SolidColorBrush x:Key="LinkDown"    Color="#EF4444"/>

        <LinearGradientBrush x:Key="AccentGrad" StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#F97316" Offset="0"/>
            <GradientStop Color="#9A3412" Offset="1"/>
        </LinearGradientBrush>

        <LinearGradientBrush x:Key="TopGlow" StartPoint="0,0" EndPoint="1,0">
            <GradientStop Color="#00FF2E3C" Offset="0"/>
            <GradientStop Color="#FFFF2E3C" Offset="0.5"/>
            <GradientStop Color="#00FF2E3C" Offset="1"/>
        </LinearGradientBrush>

        <!-- Window control buttons (minimize / maximize / close) -->
        <Style x:Key="ChromeButton" TargetType="Button">
            <Setter Property="Width" Value="42"/>
            <Setter Property="Height" Value="30"/>
            <Setter Property="Foreground" Value="#C9C9D2"/>
            <Setter Property="Background" Value="Transparent"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="FontFamily" Value="Segoe MDL2 Assets"/>
            <Setter Property="FontSize" Value="11"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="cb" CornerRadius="8" Background="{TemplateBinding Background}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="cb" Property="Background" Value="#24242B"/>
                                <Setter Property="Foreground" Value="#FFFFFF"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="cb" Property="Background" Value="#31313A"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="CloseButton" TargetType="Button" BasedOn="{StaticResource ChromeButton}">
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="cb" CornerRadius="8" Background="{TemplateBinding Background}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="cb" Property="Background" Value="#EA580C"/>
                                <Setter Property="Foreground" Value="#FFFFFF"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="cb" Property="Background" Value="#7C2D12"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="GhostButton" TargetType="Button">
            <Setter Property="Foreground" Value="{StaticResource Text}"/>
            <Setter Property="Background" Value="{StaticResource SurfaceAlt}"/>
            <Setter Property="BorderBrush" Value="{StaticResource Stroke}"/>
            <Setter Property="Height" Value="32"/>
            <Setter Property="Padding" Value="12,0"/>
            <Setter Property="FontSize" Value="12.5"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" CornerRadius="10" Background="{TemplateBinding Background}"
                                BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1"
                                Padding="{TemplateBinding Padding}"
                                RenderTransformOrigin="0.5,0.5">
                            <Border.RenderTransform>
                                <ScaleTransform x:Name="sc" ScaleX="1" ScaleY="1"/>
                            </Border.RenderTransform>
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="#22150F"/>
                                <Setter TargetName="bd" Property="BorderBrush" Value="#F97316"/>
                                <Trigger.EnterActions>
                                    <BeginStoryboard>
                                        <Storyboard>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleX" To="1.04" Duration="0:0:0.14"/>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleY" To="1.04" Duration="0:0:0.14"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </Trigger.EnterActions>
                                <Trigger.ExitActions>
                                    <BeginStoryboard>
                                        <Storyboard>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleX" To="1" Duration="0:0:0.14"/>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleY" To="1" Duration="0:0:0.14"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </Trigger.ExitActions>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="#331C10"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="PrimaryButton" TargetType="Button" BasedOn="{StaticResource GhostButton}">
            <Setter Property="Foreground" Value="#FFFFFF"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" CornerRadius="10" Background="{StaticResource AccentGrad}"
                                BorderBrush="#FB923C" BorderThickness="1"
                                Padding="{TemplateBinding Padding}"
                                RenderTransformOrigin="0.5,0.5">
                            <Border.Effect>
                                <DropShadowEffect Color="#F97316" BlurRadius="18" ShadowDepth="0" Opacity="0.55"/>
                            </Border.Effect>
                            <Border.RenderTransform>
                                <ScaleTransform x:Name="sc" ScaleX="1" ScaleY="1"/>
                            </Border.RenderTransform>
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Trigger.EnterActions>
                                    <BeginStoryboard>
                                        <Storyboard>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleX" To="1.05" Duration="0:0:0.14"/>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleY" To="1.05" Duration="0:0:0.14"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </Trigger.EnterActions>
                                <Trigger.ExitActions>
                                    <BeginStoryboard>
                                        <Storyboard>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleX" To="1" Duration="0:0:0.14"/>
                                            <DoubleAnimation Storyboard.TargetName="sc" Storyboard.TargetProperty="ScaleY" To="1" Duration="0:0:0.14"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </Trigger.ExitActions>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="#7C2D12"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="AdapterRow" TargetType="ListBoxItem">
            <Setter Property="Padding" Value="0"/>
            <Setter Property="Margin" Value="0,0,0,9"/>
            <Setter Property="Cursor" Value="SizeAll"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="ListBoxItem">
                        <Grid>
                            <Border x:Name="row" CornerRadius="12" Background="{StaticResource Surface}"
                                    BorderBrush="{StaticResource Stroke}" BorderThickness="1">
                                <Border.Effect>
                                    <DropShadowEffect Color="#F97316" BlurRadius="16" ShadowDepth="0" Opacity="0.18"/>
                                </Border.Effect>
                                <ContentPresenter/>
                            </Border>
                            <Border x:Name="bar" Width="4" HorizontalAlignment="Left" Margin="0,10,0,10"
                                    CornerRadius="2" Background="{StaticResource AccentGrad}" Opacity="0"/>
                        </Grid>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="row" Property="Background" Value="#15151A"/>
                                <Setter TargetName="row" Property="BorderBrush" Value="#4A2A10"/>
                                <Trigger.EnterActions>
                                    <BeginStoryboard>
                                        <Storyboard>
                                            <DoubleAnimation Storyboard.TargetName="bar" Storyboard.TargetProperty="Opacity" To="0.7" Duration="0:0:0.18"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </Trigger.EnterActions>
                                <Trigger.ExitActions>
                                    <BeginStoryboard>
                                        <Storyboard>
                                            <DoubleAnimation Storyboard.TargetName="bar" Storyboard.TargetProperty="Opacity" To="0" Duration="0:0:0.18"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </Trigger.ExitActions>
                            </Trigger>
                            <Trigger Property="IsSelected" Value="True">
                                <Setter TargetName="row" Property="Background" Value="{StaticResource AccentSoft}"/>
                                <Setter TargetName="row" Property="BorderBrush" Value="{StaticResource Accent}"/>
                                <Setter TargetName="bar" Property="Opacity" Value="1"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Border Background="#07070A" BorderBrush="#3A1F0D" BorderThickness="1">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <!-- ===== Custom title bar ===== -->
            <Grid Grid.Row="0" Name="TitleBar" Background="#0C0C10" Height="42">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>

                <StackPanel Grid.Column="0" Orientation="Horizontal" Margin="14,0,0,0" VerticalAlignment="Center">
                    <Border Width="18" Height="18" CornerRadius="6" Background="{StaticResource AccentGrad}">
                        <Border.Effect>
                            <DropShadowEffect Color="#F97316" BlurRadius="14" ShadowDepth="0" Opacity="0.8"/>
                        </Border.Effect>
                    </Border>
                    <TextBlock Text="NETWORK PRIORITY MANAGER" Margin="10,0,0,0" VerticalAlignment="Center"
                               FontSize="11" FontWeight="Bold" Foreground="#F0F0F4"/>
                </StackPanel>

                <StackPanel Grid.Column="2" Orientation="Horizontal" Margin="0,0,8,0" VerticalAlignment="Center">
                    <Button Name="MinBtn"  Style="{StaticResource ChromeButton}" Content="&#xE921;" ToolTip="Minimize"/>
                    <Button Name="MaxBtn"  Style="{StaticResource ChromeButton}" Content="&#xE922;" ToolTip="Maximize" Margin="2,0,0,0"/>
                    <Button Name="CloseBtn" Style="{StaticResource CloseButton}" Content="&#xE8BB;" ToolTip="Close"   Margin="2,0,0,0"/>
                </StackPanel>

                <Border Grid.ColumnSpan="3" Height="1" VerticalAlignment="Bottom" Background="{StaticResource TopGlow}"/>
            </Grid>

            <!-- ===== Body ===== -->
            <Grid Grid.Row="1" Name="Body" Margin="22,18,22,20" Opacity="0">
                <Grid.RenderTransform>
                    <TranslateTransform x:Name="bodySlide" Y="18"/>
                </Grid.RenderTransform>
                <Grid.Triggers>
                    <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                        <BeginStoryboard>
                            <Storyboard>
                                <DoubleAnimation Storyboard.TargetProperty="Opacity" From="0" To="1" Duration="0:0:0.45"/>
                                <DoubleAnimation Storyboard.TargetName="bodySlide" Storyboard.TargetProperty="Y" From="18" To="0" Duration="0:0:0.45">
                                    <DoubleAnimation.EasingFunction>
                                        <CubicEase EasingMode="EaseOut"/>
                                    </DoubleAnimation.EasingFunction>
                                </DoubleAnimation>
                            </Storyboard>
                        </BeginStoryboard>
                    </EventTrigger>
                </Grid.Triggers>

                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="*"/>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="Auto"/>
                </Grid.RowDefinitions>

                <!-- Header -->
                <Grid Grid.Row="0" Margin="0,0,0,16">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <Border Grid.Column="0" Width="46" Height="46" CornerRadius="14"
                            Background="{StaticResource AccentSoft}" BorderBrush="#5A2A12" BorderThickness="1">
                        <Border.Effect>
                            <DropShadowEffect x:Name="logoGlow" Color="#F97316" BlurRadius="22" ShadowDepth="0" Opacity="0.25"/>
                        </Border.Effect>
                        <Border.Triggers>
                            <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                                <BeginStoryboard>
                                    <Storyboard>
                                        <DoubleAnimation Storyboard.TargetName="logoGlow" Storyboard.TargetProperty="Opacity"
                                                         From="0.2" To="0.85" Duration="0:0:1.6"
                                                         AutoReverse="True" RepeatBehavior="Forever"/>
                                    </Storyboard>
                                </BeginStoryboard>
                            </EventTrigger>
                        </Border.Triggers>
                        <TextBlock Text="&#x21C5;" FontSize="22" FontWeight="Bold" Foreground="{StaticResource Accent}"
                                   HorizontalAlignment="Center" VerticalAlignment="Center"/>
                    </Border>
                    <StackPanel Grid.Column="1" Margin="14,0,0,0" VerticalAlignment="Center">
                        <TextBlock Text="Network Priority Manager" FontSize="19" FontWeight="Bold" Foreground="{StaticResource Text}"/>
                        <TextBlock Name="HeaderSub" Foreground="{StaticResource Muted}" FontSize="12.5" TextWrapping="Wrap" Margin="0,3,0,0"/>
                    </StackPanel>
                    <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center">
                        <Button Name="HelpBtn" Style="{StaticResource GhostButton}" Height="34" FontSize="12.5"/>
                        <Button Name="AboutBtn" Style="{StaticResource GhostButton}" Height="34" FontSize="12.5" Margin="8,0,0,0"/>
                        <Button Name="LangBtn" Style="{StaticResource GhostButton}" Height="34" FontSize="12.5" MinWidth="52" Margin="8,0,0,0" FontWeight="Bold"/>
                    </StackPanel>
                </Grid>

                <TextBlock Name="SubtitleText" Grid.Row="1" Margin="2,0,2,12"
                           Foreground="{StaticResource Muted}" FontSize="12.5" TextWrapping="Wrap"/>

                <ListBox Name="AdapterList" Grid.Row="2" AllowDrop="True"
                         ItemContainerStyle="{StaticResource AdapterRow}"
                         Background="Transparent" BorderThickness="0" Padding="0"
                         ScrollViewer.HorizontalScrollBarVisibility="Disabled"
                         HorizontalContentAlignment="Stretch">
                    <ListBox.ItemTemplate>
                        <DataTemplate>
                            <Grid Margin="16,13,14,13">
                                <Grid.ColumnDefinitions>
                                    <ColumnDefinition Width="34"/>
                                    <ColumnDefinition Width="*"/>
                                    <ColumnDefinition Width="Auto"/>
                                    <ColumnDefinition Width="Auto"/>
                                </Grid.ColumnDefinitions>

                                <Border Grid.Column="0" Width="28" Height="28" CornerRadius="9"
                                        Background="{StaticResource AccentGrad}" HorizontalAlignment="Right">
                                    <TextBlock Text="{Binding Rank}" Foreground="#FFFFFF"
                                               FontWeight="Bold" FontSize="12.5"
                                               HorizontalAlignment="Center" VerticalAlignment="Center"/>
                                </Border>

                                <StackPanel Grid.Column="1" Margin="12,0,12,0" VerticalAlignment="Center">
                                    <TextBlock Text="{Binding Name}" FontWeight="Bold" FontSize="13.5" Foreground="{StaticResource Text}"/>
                                    <TextBlock Text="{Binding Description}" FontSize="11.5" Foreground="{StaticResource Muted}"
                                               TextTrimming="CharacterEllipsis"/>
                                </StackPanel>

                                <Border Grid.Column="2" CornerRadius="999" Padding="10,4" VerticalAlignment="Center"
                                        Background="#141418" BorderBrush="{StaticResource Stroke}" BorderThickness="1">
                                    <StackPanel Orientation="Horizontal">
                                        <Ellipse Width="9" Height="9" VerticalAlignment="Center">
                                            <Ellipse.Style>
                                                <Style TargetType="Ellipse">
                                                    <Setter Property="Fill" Value="{StaticResource LinkDown}"/>
                                                    <Style.Triggers>
                                                        <DataTrigger Binding="{Binding RawStatus}" Value="Up">
                                                            <Setter Property="Fill" Value="{StaticResource LinkUp}"/>
                                                            <DataTrigger.EnterActions>
                                                                <BeginStoryboard>
                                                                    <Storyboard>
                                                                        <DoubleAnimation Storyboard.TargetProperty="Opacity"
                                                                                         From="1" To="0.25" Duration="0:0:1.1"
                                                                                         AutoReverse="True" RepeatBehavior="Forever"/>
                                                                    </Storyboard>
                                                                </BeginStoryboard>
                                                            </DataTrigger.EnterActions>
                                                        </DataTrigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </Ellipse.Style>
                                        </Ellipse>
                                        <TextBlock Text="{Binding Status}" Margin="7,0,0,0" FontSize="11.5" FontWeight="SemiBold" VerticalAlignment="Center">
                                            <TextBlock.Style>
                                                <Style TargetType="TextBlock">
                                                    <Setter Property="Foreground" Value="#F87171"/>
                                                    <Style.Triggers>
                                                        <DataTrigger Binding="{Binding RawStatus}" Value="Up">
                                                            <Setter Property="Foreground" Value="#4ADE80"/>
                                                        </DataTrigger>
                                                    </Style.Triggers>
                                                </Style>
                                            </TextBlock.Style>
                                        </TextBlock>
                                    </StackPanel>
                                </Border>

                                <TextBlock Grid.Column="3" Text="{Binding MetricDisplay}" Margin="10,0,0,0"
                                           FontSize="11.5" FontFamily="Consolas" VerticalAlignment="Center"
                                           Foreground="#C6C6D0"/>
                            </Grid>
                        </DataTemplate>
                    </ListBox.ItemTemplate>
                </ListBox>

                <Border Grid.Row="3" Margin="0,14,0,0" CornerRadius="10" Padding="12,9"
                        Background="{StaticResource Surface}" BorderBrush="#3A1F0D" BorderThickness="1">
                    <StackPanel Orientation="Horizontal">
                        <Border Width="6" Height="6" CornerRadius="3" VerticalAlignment="Center" Background="{StaticResource Accent}"/>
                        <TextBlock Name="StatusText" Margin="9,0,0,0" Foreground="#DCDCE4" FontSize="12.5" TextWrapping="Wrap"/>
                    </StackPanel>
                </Border>

                <Grid Grid.Row="4" Margin="0,14,0,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <StackPanel Grid.Column="0" Orientation="Horizontal">
                        <Button Name="ApplyBtn" Style="{StaticResource PrimaryButton}" MinWidth="88"/>
                        <Button Name="RefreshBtn" Style="{StaticResource GhostButton}" Margin="6,0,0,0"/>
                        <Button Name="PersistBtn" Style="{StaticResource GhostButton}" Margin="6,0,0,0"/>
                    </StackPanel>
                    <StackPanel Grid.Column="2" Orientation="Horizontal">
                        <Button Name="RestoreBtn" Style="{StaticResource GhostButton}"/>
                        <Button Name="TrayBtn" Style="{StaticResource GhostButton}" Margin="6,0,0,0"/>
                    </StackPanel>
                </Grid>

                <!-- Dedication -->
                <TextBlock Grid.Row="5" Margin="0,12,2,0" HorizontalAlignment="Center"
                           FlowDirection="RightToLeft" FontSize="12" Foreground="#A7A7B2"
                           FontFamily="Segoe UI, Tahoma" Text="&#x1F5A4; &#x0628;&#x0647; &#x06CC;&#x0627;&#x062F; &#x062C;&#x0627;&#x0648;&#x06CC;&#x062F;&#x0646;&#x0627;&#x0645; &#x0647;&#x0627;&#x06CC; &#x0648;&#x0637;&#x0646;"/>
            </Grid>
        </Grid>
    </Border>
</Window>
"@

$window = $null
try {
    $reader = New-Object System.Xml.XmlNodeReader $xaml
    $window = [Windows.Markup.XamlReader]::Load($reader)
} catch {
    Write-AppLog "XamlReader (XmlNodeReader) failed: $($_.Exception.ToString())"
    $window = $null
}
if (-not $window) {
    try { $window = [Windows.Markup.XamlReader]::Parse($xaml.OuterXml) }
    catch { Write-AppLog "XamlReader.Parse failed: $($_.Exception.ToString())" }
}
if (-not $window) {
    Show-FatalError "Error building the window" "The app's GUI could not be built (XAML failed to load)."
    exit 1
}
try {
    if (Test-Path $IconFile) {
        $iconUri = New-Object System.Uri($IconFile, [System.UriKind]::Absolute)
        $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create($iconUri)
    }
} catch { Write-AppLog "Window icon load failed: $($_.Exception.Message)" }

$window.Add_Loaded({
    param($sender, $e)
    try {
        $w = $sender -as [System.Windows.Window]
        if ($w) { $w.Topmost = $false; $w.Activate() }
    } catch { Write-AppLog "Loaded handler: $($_.Exception.Message)" }
})

# Log any unhandled error in event handlers without closing the app
try {
    $window.Dispatcher.Add_UnhandledException({
        param($sender, $e)
        try { Write-AppLog ("Dispatcher unhandled: " + $e.Exception.ToString()) } catch {}
        $e.Handled = $true
    })
} catch { Write-AppLog "Dispatcher hook failed: $($_.Exception.Message)" }

$ctrl = @{}
foreach ($n in @("HeaderSub","HelpBtn","AboutBtn","LangBtn","SubtitleText","AdapterList","StatusText",
                 "ApplyBtn","RefreshBtn","RestoreBtn","TrayBtn","PersistBtn",
                 "TitleBar","MinBtn","MaxBtn","CloseBtn")) {
    $ctrl[$n] = $window.FindName($n)
}
$missing = @($ctrl.Keys | Where-Object { -not $ctrl[$_] })
if ($missing.Count -gt 0) {
    Show-FatalError "GUI error" ("These UI elements were not found:`n" + ($missing -join ", "))
    exit 1
}

$AdapterList = $ctrl.AdapterList

# ===================== Custom title bar (drag / minimize / maximize / close) =====================
function Update-MaxGlyph {
    try {
        if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
            $ctrl.MaxBtn.Content = [char]0xE923   # restore glyph
            $ctrl.MaxBtn.ToolTip = "Restore"
        } else {
            $ctrl.MaxBtn.Content = [char]0xE922   # maximize glyph
            $ctrl.MaxBtn.ToolTip = "Maximize"
        }
    } catch {}
}

$ctrl.TitleBar.Add_MouseLeftButtonDown({
    param($s, $e)
    try {
        if ($e.ClickCount -eq 2) {
            if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
                $window.WindowState = [System.Windows.WindowState]::Normal
            } else {
                $window.WindowState = [System.Windows.WindowState]::Maximized
            }
            Update-MaxGlyph
        } else {
            $window.DragMove()
        }
    } catch { Write-AppLog "TitleBar drag: $($_.Exception.Message)" }
})

$ctrl.MinBtn.Add_Click({ $window.WindowState = [System.Windows.WindowState]::Minimized })
$ctrl.MaxBtn.Add_Click({
    if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
        $window.WindowState = [System.Windows.WindowState]::Normal
    } else {
        $window.WindowState = [System.Windows.WindowState]::Maximized
    }
    Update-MaxGlyph
})
$ctrl.CloseBtn.Add_Click({ $window.Close() })
$window.Add_StateChanged({ Update-MaxGlyph })

function Set-Status([string]$msg) { $ctrl.StatusText.Text = $msg }
function Info([string]$msg) {
    [System.Windows.MessageBox]::Show($msg, (T "AppTitle"), "OK", "Information") | Out-Null
}


# ===================== Custom dialogs (Help / About) =====================
function Open-Url([string]$url) {
    try { Start-Process $url } catch { Write-AppLog "Open-Url: $($_.Exception.Message)" }
}

function Set-DialogDirection($dlg) {
    try {
        if (Is-RTL) {
            $dlg.FlowDirection = [System.Windows.FlowDirection]::RightToLeft
            $dlg.FontFamily = New-Object System.Windows.Media.FontFamily "Segoe UI, Tahoma"
        } else {
            $dlg.FlowDirection = [System.Windows.FlowDirection]::LeftToRight
        }
    } catch {}
}

function Show-CustomDialog {
    param(
        [string]$Title,
        [string]$Subtitle,
        [string]$Body,
        [switch]$WithLink
    )
    $dlgXamlText = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        SizeToContent="Height" Width="560" MaxHeight="640"
        WindowStartupLocation="CenterOwner" ShowInTaskbar="False"
        FontFamily="Segoe UI" FontSize="13">
    <Border CornerRadius="16" Background="#0B0B0F" BorderBrush="#3A1F0D" BorderThickness="1" Padding="0">
        <Border.Effect>
            <DropShadowEffect Color="#000000" BlurRadius="30" ShadowDepth="0" Opacity="0.7"/>
        </Border.Effect>
        <Grid Margin="0">
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <Border Grid.Row="0" Name="DlgBar" CornerRadius="16,16,0,0" Background="#141419" Padding="18,14">
                <Grid>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <Border Grid.Column="0" Width="34" Height="34" CornerRadius="11" Background="#2A150D" BorderBrush="#5A2A12" BorderThickness="1">
                        <TextBlock Text="&#x21C5;" FontSize="16" FontWeight="Bold" Foreground="#F97316"
                                   HorizontalAlignment="Center" VerticalAlignment="Center"/>
                    </Border>
                    <StackPanel Grid.Column="1" Margin="12,0,0,0" VerticalAlignment="Center">
                        <TextBlock Name="DlgTitle" FontSize="15" FontWeight="Bold" Foreground="#F6F6F8"/>
                        <TextBlock Name="DlgSub" FontSize="11.5" Foreground="#A7A7B2" TextWrapping="Wrap"/>
                    </StackPanel>
                    <Button Grid.Column="2" Name="DlgClose" Content="&#x2715;" Width="30" Height="30"
                            Foreground="#A7A7B2" Background="Transparent" BorderThickness="0" Cursor="Hand" FontSize="12"/>
                </Grid>
            </Border>

            <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto" Margin="18,16,18,0">
                <StackPanel>
                    <Border CornerRadius="12" Background="#111114" BorderBrush="#2A2A31" BorderThickness="1" Padding="14,12">
                        <TextBlock Name="DlgBody" Foreground="#DCDCE4" FontSize="12.5" TextWrapping="Wrap" LineHeight="20"/>
                    </Border>
                    <StackPanel Name="DlgLinkPanel" Orientation="Horizontal" Margin="2,14,0,0" Visibility="Collapsed">
                        <TextBlock Name="DlgTelegramLabel" Text="Telegram:" Foreground="#A7A7B2" FontSize="12" VerticalAlignment="Center"/>
                        <TextBlock Name="DlgLink" Text="https://t.me/aliroxtg" Margin="7,0,0,0" FontSize="12" FontWeight="SemiBold"
                                   Foreground="#38BDF8" Cursor="Hand" TextDecorations="Underline" VerticalAlignment="Center"/>
                    </StackPanel>
                    <StackPanel Name="DlgGithubPanel" Orientation="Horizontal" Margin="2,8,0,0" Visibility="Collapsed">
                        <TextBlock Name="DlgGithubLabel" Text="GitHub:" Foreground="#A7A7B2" FontSize="12" VerticalAlignment="Center"/>
                        <TextBlock Name="DlgGithubLink" Text="https://github.com/a1irox/NetworkSuite" Margin="7,0,0,0" FontSize="12" FontWeight="SemiBold"
                                   Foreground="#38BDF8" Cursor="Hand" TextDecorations="Underline" VerticalAlignment="Center"/>
                    </StackPanel>
                    <StackPanel Name="DlgDonatePanel" Orientation="Horizontal" Margin="2,8,0,0" Visibility="Collapsed">
                        <TextBlock Name="DlgDonateLabel" Text="Donate:" Foreground="#A7A7B2" FontSize="12" VerticalAlignment="Center"/>
                        <TextBlock Name="DlgDonateLink" Text="https://donofa.ir/alirox" Margin="7,0,0,0" FontSize="12" FontWeight="SemiBold"
                                   Foreground="#38BDF8" Cursor="Hand" TextDecorations="Underline" VerticalAlignment="Center"/>
                    </StackPanel>
                </StackPanel>
            </ScrollViewer>

            <Border Grid.Row="2" Margin="18,16,18,18">
                <Button Name="DlgOk" Content="OK" HorizontalAlignment="Right" MinWidth="96" Height="34"
                        Foreground="#FFFFFF" Background="#9A3412" BorderThickness="0" Cursor="Hand" FontWeight="SemiBold"/>
            </Border>
        </Grid>
    </Border>
</Window>
'@
    try {
        [xml]$dx = $dlgXamlText
        $reader2 = New-Object System.Xml.XmlNodeReader $dx
        $dlg = [Windows.Markup.XamlReader]::Load($reader2)
        $dlg.Owner = $window
        Set-DialogDirection $dlg
        $dlg.FindName("DlgTitle").Text = $Title
        $dlg.FindName("DlgSub").Text   = $Subtitle
        $dlg.FindName("DlgBody").Text  = $Body
        if ($WithLink) {
            $dlg.FindName("DlgLinkPanel").Visibility = "Visible"
            $dlg.FindName("DlgTelegramLabel").Text = if (Is-RTL) { "تلگرام:" } else { "Telegram:" }
            $dlg.FindName("DlgLink").Add_MouseLeftButtonUp({ Open-Url "https://t.me/aliroxtg" })
            $dlg.FindName("DlgGithubPanel").Visibility = "Visible"
            $dlg.FindName("DlgGithubLabel").Text = if (Is-RTL) { "گیت‌هاب:" } else { "GitHub:" }
            $dlg.FindName("DlgGithubLink").Add_MouseLeftButtonUp({ Open-Url "https://github.com/a1irox/NetworkSuite" })
            $dlg.FindName("DlgDonatePanel").Visibility = "Visible"
            $dlg.FindName("DlgDonateLabel").Text = if (Is-RTL) { "حمایت مالی:" } else { "Donate:" }
            $dlg.FindName("DlgDonateLink").Add_MouseLeftButtonUp({ Open-Url "https://donofa.ir/alirox" })
        }
        $dlg.FindName("DlgBar").Add_MouseLeftButtonDown({ try { $dlg.DragMove() } catch {} })
        $dlg.FindName("DlgClose").Add_Click({ $dlg.Close() })
        $dlg.FindName("DlgOk").Add_Click({ $dlg.Close() })
        $dlg.ShowDialog() | Out-Null
    } catch {
        Write-AppLog "Show-CustomDialog: $($_.Exception.ToString())"
        [System.Windows.MessageBox]::Show($Body, $Title, "OK", "Information") | Out-Null
    }
}


function Get-HelpSections {
    if (Is-RTL) {
        return @(
            @{ Title = "۱. این برنامه چه کاری می‌کند؟"
               Lines = @(
                 "ویندوز با معیاری به نام Interface Metric تصمیم می‌گیرد اول از کدام کارت شبکه استفاده کند؛ هر چه این عدد کمتر باشد، اولویت بیشتر است.",
                 "این برنامه همان ترتیب را به شکل تصویری در اختیار شما می‌گذارد: ردیف اول مسیر پیش‌فرض اینترنت می‌شود.",
                 "همچنین گزینه Automatic Metric را خاموش می‌کند تا ویندوز بعداً انتخاب شما را بی‌صدا تغییر ندهد."
               ) },
            @{ Title = "۲. شروع سریع (۳ مرحله)"
               Lines = @(
                 "مرحله ۱ - ردیف کارت‌های شبکه را بکشید و بالا/پایین ببرید تا ترتیب دلخواه شود.",
                 "مرحله ۲ - دکمه اعمال را بزنید. متریک‌های جدید فوراً نوشته می‌شوند.",
                 "مرحله ۳ - نوار وضعیت پایین برنامه را ببینید؛ موفقیت یا خطا را همان‌جا اعلام می‌کند."
               ) },
            @{ Title = "۳. هر ردیف چه می‌گوید؟"
               Lines = @(
                 "عدد داخل مربع - رتبه اولویت فعلی (۱ = بالاترین اولویت).",
                 "نام و توضیح - نام کارت شبکه و مشخصات سخت‌افزاری آن.",
                 "دایره سبز = متصل. دایره قرمز = قطع یا غیرفعال.",
                 "عدد سمت دیگر ردیف، متریک فعلی کارت شبکه است."
               ) },
            @{ Title = "۴. دکمه‌ها"
               Lines = @(
                 "اعمال - ترتیب جدید اولویت را در ویندوز ثبت می‌کند.",
                 "بازخوانی - لیست کارت‌ها و وضعیت زنده آن‌ها را دوباره می‌خواند.",
                 "بازگردانی تنظیمات قبلی - متریک‌ها را به حالت پیش از نخستین اعمال شما برمی‌گرداند.",
                 "کوچک کردن به تری - برنامه کنار ساعت ویندوز اجرا می‌ماند؛ با دوبار کلیک روی آیکن برمی‌گردد.",
                 "دکمه EN/FA - زبان برنامه را بین فارسی و انگلیسی جابجا می‌کند."
               ) },
            @{ Title = "۵. خوب است بدانید"
               Lines = @(
                 "برنامه به دسترسی مدیر (Administrator) نیاز دارد و در صورت لزوم خودش را با دسترسی بالا اجرا می‌کند.",
                 "ترتیب انتخابی شما ذخیره می‌شود؛ کارت شبکه جدید انتهای لیست اضافه و در نوار وضعیت اعلام می‌شود.",
                 "کارت قطع‌شده هم قابل جابجایی است؛ اولویت به‌محض وصل شدن اعمال می‌شود.",
                 "تغییرات بی‌درنگ اثر می‌کنند و نیازی به ری‌استارت نیست."
               ) },
            @{ Title = "۶. رفع اشکال"
               Lines = @(
                 "چیزی تغییر نکرد؟ بازخوانی را بزنید، عدد متریک را بررسی کنید و مطمئن شوید کارت شبکه فعال است.",
                 "یک مورد اعمال نشد؟ بعضی کارت‌های مجازی یا قفل‌شده توسط درایور اجازه تغییر متریک نمی‌دهند.",
                 "باز هم مشکل داشتید؟ گزارش کامل اینجا نوشته می‌شود: %TEMP%\NetworkSuite_error.log"
               ) }
        )
    }
    return @(
        @{ Title = "1. What this app does"
           Lines = @(
             "Windows decides which network adapter to use first by an Interface Metric - the lower the metric, the higher the priority.",
             "This app lets you set that order visually: the top row becomes your default internet route.",
             "It also turns off Automatic Metric, so Windows cannot silently override your choice later."
           ) },
        @{ Title = "2. Quick start (3 steps)"
           Lines = @(
             "Step 1 - Drag any adapter row up or down until the list matches the order you want.",
             "Step 2 - Click Apply. The new metrics are written immediately.",
             "Step 3 - Check the status bar at the bottom: it confirms success or shows what failed."
           ) },
        @{ Title = "3. Reading a row"
           Lines = @(
             "Number badge - the current priority rank (1 = highest priority).",
             "Name / description - the adapter name and hardware description.",
             "Green dot = Connected. Red dot = Disconnected or Disabled.",
             "The right-hand number is the current interface metric."
           ) },
        @{ Title = "4. Buttons"
           Lines = @(
             "Apply - writes the new priority order to Windows.",
             "Refresh - reloads adapters and their live status.",
             "Restore previous settings - reverts to the metrics saved before your very first Apply.",
             "Minimize to tray - keeps the app running next to the clock; double-click the tray icon to bring it back.",
             "EN/FA button - switches the interface between English and Persian."
           ) },
        @{ Title = "5. Good to know"
           Lines = @(
             "The app needs administrator rights and restarts itself elevated if needed.",
             "Your order is remembered, so new adapters appear at the bottom and are flagged in the status bar.",
             "Disconnected adapters can still be reordered; the priority applies as soon as they come back up.",
             "Changes take effect right away - no reboot is required."
           ) },
        @{ Title = "6. Troubleshooting"
           Lines = @(
             "Nothing changed? Click Refresh, confirm the metric numbers, and make sure the adapter is enabled.",
             "An item failed to apply? Some virtual or driver-locked adapters block metric changes.",
             "Still stuck? A detailed log is written to: %TEMP%\NetworkSuite_error.log"
           ) }
    )
}

function Show-HelpDialog {
    $dlgXamlText = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        Width="620" Height="620"
        WindowStartupLocation="CenterOwner" ShowInTaskbar="False"
        FontFamily="Segoe UI" FontSize="13">
    <Border CornerRadius="16" Background="#0B0B0F" BorderBrush="#3A1F0D" BorderThickness="1">
        <Border.Effect>
            <DropShadowEffect Color="#000000" BlurRadius="30" ShadowDepth="0" Opacity="0.7"/>
        </Border.Effect>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <Border Grid.Row="0" Name="DlgBar" CornerRadius="16,16,0,0" Background="#141419" Padding="18,14">
                <Grid>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <Border Grid.Column="0" Width="34" Height="34" CornerRadius="11" Background="#2A150D" BorderBrush="#5A2A12" BorderThickness="1">
                        <TextBlock Text="?" FontSize="16" FontWeight="Bold" Foreground="#F97316"
                                   HorizontalAlignment="Center" VerticalAlignment="Center"/>
                    </Border>
                    <StackPanel Grid.Column="1" Margin="12,0,0,0" VerticalAlignment="Center">
                        <TextBlock Name="DlgTitle" FontSize="15" FontWeight="Bold" Foreground="#F6F6F8"/>
                        <TextBlock Name="DlgSub" FontSize="11.5" Foreground="#A7A7B2" TextWrapping="Wrap"/>
                    </StackPanel>
                    <Button Grid.Column="2" Name="DlgClose" Content="&#x2715;" Width="30" Height="30"
                            Foreground="#A7A7B2" Background="Transparent" BorderThickness="0" Cursor="Hand" FontSize="12"/>
                </Grid>
            </Border>

            <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto" Margin="18,16,10,0" Padding="0,0,8,0">
                <StackPanel Name="HelpStack"/>
            </ScrollViewer>

            <Border Grid.Row="2" Margin="18,14,18,18">
                <Button Name="DlgOk" HorizontalAlignment="Right" MinWidth="96" Height="34"
                        Foreground="#FFFFFF" Background="#9A3412" BorderThickness="0" Cursor="Hand" FontWeight="SemiBold"/>
            </Border>
        </Grid>
    </Border>
</Window>
'@
    try {
        [xml]$dx = $dlgXamlText
        $reader2 = New-Object System.Xml.XmlNodeReader $dx
        $dlg = [Windows.Markup.XamlReader]::Load($reader2)
        $dlg.Owner = $window
        Set-DialogDirection $dlg
        $dlg.FindName("DlgTitle").Text = T "HelpTitle"
        $dlg.FindName("DlgSub").Text   = T "HelpSub"
        $dlg.FindName("DlgOk").Content = T "HelpOk"
        $stack = $dlg.FindName("HelpStack")

        foreach ($sec in (Get-HelpSections)) {
            $card = New-Object System.Windows.Controls.Border
            $card.CornerRadius = New-Object System.Windows.CornerRadius 12
            $card.Background   = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.ColorConverter]::ConvertFromString("#111114"))
            $card.BorderBrush  = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.ColorConverter]::ConvertFromString("#2A2A31"))
            $card.BorderThickness = New-Object System.Windows.Thickness 1
            $card.Padding = New-Object System.Windows.Thickness 14, 12, 14, 12
            $card.Margin  = New-Object System.Windows.Thickness 0, 0, 0, 12

            $inner = New-Object System.Windows.Controls.StackPanel

            $h = New-Object System.Windows.Controls.TextBlock
            $h.Text = [string]$sec.Title
            $h.FontWeight = "Bold"
            $h.FontSize = 13.5
            $h.Foreground = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.ColorConverter]::ConvertFromString("#FB923C"))
            $h.Margin = New-Object System.Windows.Thickness 0, 0, 0, 8
            [void]$inner.Children.Add($h)

            foreach ($line in $sec.Lines) {
                $row = New-Object System.Windows.Controls.StackPanel
                $row.Orientation = "Horizontal"
                $row.Margin = New-Object System.Windows.Thickness 0, 0, 0, 6

                $dot = New-Object System.Windows.Shapes.Ellipse
                $dot.Width = 5; $dot.Height = 5
                $dot.VerticalAlignment = "Top"
                $dot.Margin = New-Object System.Windows.Thickness 2, 7, 9, 0
                $dot.Fill = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.ColorConverter]::ConvertFromString("#EF4444"))
                [void]$row.Children.Add($dot)

                $t = New-Object System.Windows.Controls.TextBlock
                $t.Text = [string]$line
                $t.TextWrapping = "Wrap"
                $t.FontSize = 12.5
                $t.LineHeight = 19
                $t.Width = 500
                $t.Foreground = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.ColorConverter]::ConvertFromString("#DCDCE4"))
                [void]$row.Children.Add($t)

                [void]$inner.Children.Add($row)
            }

            $card.Child = $inner
            [void]$stack.Children.Add($card)
        }

        $dlg.FindName("DlgBar").Add_MouseLeftButtonDown({ try { $dlg.DragMove() } catch {} })
        $dlg.FindName("DlgClose").Add_Click({ $dlg.Close() })
        $dlg.FindName("DlgOk").Add_Click({ $dlg.Close() })
        $dlg.ShowDialog() | Out-Null
    } catch {
        Write-AppLog "Show-HelpDialog: $($_.Exception.ToString())"
        [System.Windows.MessageBox]::Show((T "HelpText"), (T "Help"), "OK", "Information") | Out-Null
    }
}

# ===================== Priority logic =====================
$script:AdapterCollection = New-Object System.Collections.ObjectModel.ObservableCollection[Object]
$AdapterList.ItemsSource = $script:AdapterCollection

function New-DisplayItem($snap, $rank) {
    $metricDisplay = if ($null -ne $snap.MetricV4) { "Metric: $($snap.MetricV4)" } else { "-" }
    return [PSCustomObject]@{
        IfIndex       = $snap.IfIndex
        Name          = $snap.Name
        Description   = $snap.Description
        Status        = $snap.Status
        RawStatus     = $snap.RawStatus
        Rank          = $rank
        MetricDisplay = $metricDisplay
        HasV6         = $snap.HasV6
    }
}

function Update-Ranks {
    for ($i = 0; $i -lt $script:AdapterCollection.Count; $i++) {
        $script:AdapterCollection[$i].Rank = $i + 1
    }
    $AdapterList.Items.Refresh()
}

function Load-Adapters {
    param([switch]$UseSavedOrder)
    $snapshots = Get-AdapterSnapshot
    $script:AdapterCollection.Clear()

    $ordered = $snapshots | Sort-Object -Property @{Expression = {
        if ($null -ne $_.MetricV4) { $_.MetricV4 } else { 9999 }
    }}

    if ($UseSavedOrder -and (Test-Path $OrderFile)) {
        try {
            $savedOrder = Get-Content $OrderFile -Raw | ConvertFrom-Json
            $savedNames = @($savedOrder.Order)
            $inSaved  = @(); $notSaved = @()
            foreach ($s in $snapshots) {
                if ($savedNames -contains $s.Name) { $inSaved += $s } else { $notSaved += $s }
            }
            $inSaved = $inSaved | Sort-Object { [array]::IndexOf($savedNames, $_.Name) }
            $ordered = @($inSaved) + @($notSaved)
        } catch { Write-AppLog "Load saved order failed: $($_.Exception.Message)" }
    }

    $rank = 1
    foreach ($s in $ordered) {
        $script:AdapterCollection.Add((New-DisplayItem $s $rank))
        $rank++
    }
}

function Show-NewAdapterAlert([string]$names) {
    try {
        if (-not $notifyIcon) { return }
        $wasHidden = -not $notifyIcon.Visible
        $notifyIcon.Visible = $true
        $notifyIcon.ShowBalloonTip(4000, "Network Priority Manager",
            "$(T 'NewAdapter') $names`n$(T 'NewAdapterT')",
            [System.Windows.Forms.ToolTipIcon]::Info)
        if ($wasHidden -and $window.IsVisible) {
            $hideTimer = New-Object System.Windows.Threading.DispatcherTimer
            $hideTimer.Interval = [TimeSpan]::FromSeconds(6)
            $hideTimer.Add_Tick({
                param($s2, $e2)
                if ($window.IsVisible) { $notifyIcon.Visible = $false }
                $s2.Stop()
            })
            $hideTimer.Start()
        }
    } catch { Write-AppLog "Show-NewAdapterAlert error: $($_.Exception.Message)" }
}

function Sync-AdapterList {
    try {
        $snap = Get-AdapterSnapshot
        $snapByIndex = @{}
        foreach ($s in $snap) { $snapByIndex[$s.IfIndex] = $s }
        $currentIndexes = @($script:AdapterCollection | ForEach-Object { $_.IfIndex })

        foreach ($item in $script:AdapterCollection) {
            if ($snapByIndex.ContainsKey($item.IfIndex)) {
                $s = $snapByIndex[$item.IfIndex]
                $item.Status        = $s.Status
                $item.RawStatus     = $s.RawStatus
                $item.MetricDisplay = if ($null -ne $s.MetricV4) { "$(T 'Metric') $($s.MetricV4)" } else { "-" }
                $item.HasV6         = $s.HasV6
            } else {
                $item.Status    = (T "NotFound")
                $item.RawStatus = "NotFound"
            }
        }

        $newOnes = @($snap | Where-Object { $currentIndexes -notcontains $_.IfIndex })
        if ($newOnes.Count -gt 0) {
            foreach ($n in $newOnes) {
                $script:AdapterCollection.Add((New-DisplayItem $n ($script:AdapterCollection.Count + 1)))
            }
            Update-Ranks
            $names = ($newOnes | ForEach-Object { $_.Name }) -join ', '
            Show-NewAdapterAlert $names
            Set-Status "$(T 'NewAdapter') $names — $(T 'NewAdapterT')"
        }

        $AdapterList.Items.Refresh()
    } catch { Write-AppLog "Sync-AdapterList error: $($_.Exception.Message)" }
}

# --- Drag & Drop ---
$script:DraggedItem = $null
function Find-Ancestor {
    param($element, [type]$type)
    $current = $element
    while ($null -ne $current -and -not ($current -is $type)) {
        $current = [System.Windows.Media.VisualTreeHelper]::GetParent($current)
    }
    return $current
}

$AdapterList.Add_PreviewMouseLeftButtonDown({
    param($s, $e)
    try {
        $hit = $s.InputHitTest($e.GetPosition($s))
        $lbItem = Find-Ancestor $hit ([System.Windows.Controls.ListBoxItem])
        if ($lbItem) {
            $script:DraggedItem = $lbItem.DataContext
            [System.Windows.DragDrop]::DoDragDrop($lbItem, $lbItem.DataContext, [System.Windows.DragDropEffects]::Move) | Out-Null
        }
    } catch { Write-AppLog "Drag start error: $($_.Exception.Message)" }
})

$AdapterList.Add_Drop({
    param($s, $e)
    try {
        $hit = $s.InputHitTest($e.GetPosition($s))
        $lbItem = Find-Ancestor $hit ([System.Windows.Controls.ListBoxItem])
        if ($lbItem -and $script:DraggedItem) {
            $targetItem = $lbItem.DataContext
            $oldIndex = $script:AdapterCollection.IndexOf($script:DraggedItem)
            $newIndex = $script:AdapterCollection.IndexOf($targetItem)
            if ($oldIndex -ge 0 -and $newIndex -ge 0 -and $oldIndex -ne $newIndex) {
                $script:AdapterCollection.Move($oldIndex, $newIndex)
                Update-Ranks
            }
        }
    } catch { Write-AppLog "Drop error: $($_.Exception.Message)" }
    $script:DraggedItem = $null
})

function Backup-IfNeeded {
    if (-not (Test-Path $BackupFile)) {
        (Get-AdapterSnapshot) | ConvertTo-Json -Depth 5 | Set-Content -Path $BackupFile -Encoding UTF8
    }
}


# ===================== Persistence (survive a Windows restart) =====================
# Windows resets InterfaceMetric / AutomaticMetric after some restarts, driver
# updates or network stack resets. To make the user's choice stick, we save the
# applied plan to plan.json and register a Scheduled Task that runs a small
# helper script as SYSTEM at every boot (and at logon) to re-apply it.

function Save-ApplyPlan {
    param($Entries)
    try {
        @{ Saved = (Get-Date -Format 's'); Items = $Entries } |
            ConvertTo-Json -Depth 5 | Set-Content -Path $PlanFile -Encoding UTF8
    } catch { Write-AppLog "Save-ApplyPlan: $($_.Exception.Message)" }
}

function Write-PersistScript {
    $body = @'
# Auto-generated by Network Priority Manager. Re-applies saved interface metrics.
$ErrorActionPreference = "SilentlyContinue"
$ConfigDir = Join-Path $env:APPDATA "NetworkSuite"
if (-not (Test-Path $ConfigDir)) { $ConfigDir = "C:\ProgramData\NetworkSuite" }
$PlanFile = Join-Path $ConfigDir "plan.json"
$Log      = Join-Path $ConfigDir "persist.log"
function L($m) { try { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $m" | Add-Content -Path $Log -Encoding UTF8 } catch {} }
if (-not (Test-Path $PlanFile)) { L "no plan file"; return }
$plan = Get-Content $PlanFile -Raw | ConvertFrom-Json

# Adapters are not always ready right after boot, so re-apply a few times.
foreach ($delay in 5, 20, 45, 90) {
    Start-Sleep -Seconds $delay
    foreach ($it in $plan.Items) {
        $a = Get-NetAdapter -Name $it.Name -ErrorAction SilentlyContinue
        if (-not $a -and $it.Description) {
            $a = Get-NetAdapter -ErrorAction SilentlyContinue |
                 Where-Object { $_.InterfaceDescription -eq $it.Description } | Select-Object -First 1
        }
        if (-not $a) { L "adapter not found: $($it.Name)"; continue }
        try {
            Set-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -InterfaceMetric $it.Metric -AutomaticMetric Disabled -ErrorAction Stop
            Get-NetRoute -InterfaceIndex $a.ifIndex -DestinationPrefix "0.0.0.0/0" -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                Set-NetRoute -RouteMetric 0 -Confirm:$false -ErrorAction SilentlyContinue
            # IPv6 is intentionally left untouched - this tool only manages IPv4.
            L "applied $($a.Name) -> $($it.Metric)"
        } catch { L "failed $($it.Name): $($_.Exception.Message)" }
    }
}
'@
    try {
        Set-Content -Path $PersistPs1 -Value $body -Encoding UTF8
        # Keep a machine-wide copy of the plan so the SYSTEM task can read it too.
        $pd = "C:\ProgramData\NetworkSuite"
        if (-not (Test-Path $pd)) { New-Item -ItemType Directory -Path $pd -Force | Out-Null }
        if (Test-Path $PlanFile) { Copy-Item $PlanFile (Join-Path $pd "plan.json") -Force }
        return $true
    } catch { Write-AppLog "Write-PersistScript: $($_.Exception.Message)"; return $false }
}

function Test-PersistEnabled {
    try { return [bool](Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) }
    catch { return $false }
}

function Enable-Persist {
    try {
        [void](Write-PersistScript)
        $action  = New-ScheduledTaskAction -Execute "powershell.exe" `
                    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PersistPs1`""
        $t1 = New-ScheduledTaskTrigger -AtStartup
        $t2 = New-ScheduledTaskTrigger -AtLogOn
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
        $settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                        -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
        Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($t1, $t2) `
            -Principal $principal -Settings $settings -Force -ErrorAction Stop | Out-Null
        Write-AppLog "Persist task registered."
        return $true
    } catch {
        Write-AppLog "Enable-Persist: $($_.Exception.Message)"
        return $false
    }
}

function Disable-Persist {
    try {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Write-AppLog "Persist task removed."
        return $true
    } catch { Write-AppLog "Disable-Persist: $($_.Exception.Message)"; return $false }
}

function Update-PersistButton {
    try {
        $on = Test-PersistEnabled
        $ctrl.PersistBtn.Content = if ($on) { T "PersistOn" } else { T "PersistOff" }
        $ctrl.PersistBtn.ToolTip = T "PersistTip"
    } catch {}
}

$ctrl.PersistBtn.Add_Click({
    try {
        if (Test-PersistEnabled) {
            [void](Disable-Persist)
            Set-Status (T "PersistDis")
        } else {
            if (Enable-Persist) { Set-Status (T "PersistEn") }
            else { Set-Status "$(T 'PersistErr') $(T 'ErrTitle')" }
        }
        Update-PersistButton
    } catch {
        Write-AppLog "Persist click: $($_.Exception.Message)"
        Set-Status "$(T 'PersistErr') $($_.Exception.Message)"
    }
})

$ctrl.ApplyBtn.Add_Click({
    try {
        Backup-IfNeeded
        $errors = @()
        $planEntries = @()
        $rank = 1
        foreach ($item in $script:AdapterCollection) {
            $metric = $rank * 10
            $planEntries += [PSCustomObject]@{
                Name = $item.Name; Description = $item.Description; Metric = $metric; HasV6 = [bool]$item.HasV6
            }
            try {
                # IMPORTANT: AutomaticMetric must be explicitly disabled, otherwise
                # Windows keeps recalculating its own metric from the link speed
                # (e.g. it usually favors Ethernet over Wi-Fi) and silently
                # overrides the manual value we just set.
                Set-NetIPInterface -InterfaceIndex $item.IfIndex -AddressFamily IPv4 -InterfaceMetric $metric -AutomaticMetric Disabled -ErrorAction Stop | Out-Null
                # IPv6 is intentionally left untouched - this tool only manages IPv4,
                # whatever the user has configured for IPv6 stays exactly as-is.

                # IMPORTANT: Windows' actual routing decision uses the EFFECTIVE
                # metric of the default route, which is InterfaceMetric + RouteMetric.
                # RouteMetric is a separate per-route value (often set by DHCP) that
                # Set-NetIPInterface does NOT touch. If, say, Wi-Fi's default route
                # has a low RouteMetric, its effective total can still beat a LAN
                # adapter with a lower InterfaceMetric - which is exactly the "LAN
                # is set to 10 but Windows still uses Wi-Fi" symptom. Zeroing the
                # RouteMetric on the default route removes that hidden offset, so
                # the effective metric matches the InterfaceMetric we just set.
                try {
                    Get-NetRoute -InterfaceIndex $item.IfIndex -DestinationPrefix "0.0.0.0/0" -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                        Set-NetRoute -RouteMetric 0 -Confirm:$false -ErrorAction SilentlyContinue
                } catch { Write-AppLog "RouteMetric reset for $($item.Name): $($_.Exception.Message)" }

                Write-AppLog "Apply: $($item.Name) (ifIndex $($item.IfIndex)) -> metric $metric (AutomaticMetric disabled, RouteMetric reset)"
            } catch { $errors += "$($item.Name): $($_.Exception.Message)" }
            $rank++
        }

        $orderNames = $script:AdapterCollection | ForEach-Object { $_.Name }
        @{ Order = $orderNames } | ConvertTo-Json | Set-Content -Path $OrderFile -Encoding UTF8

        # Save the plan and make sure it is re-applied after every restart.
        Save-ApplyPlan $planEntries
        if (-not (Test-PersistEnabled)) { [void](Enable-Persist) } else { [void](Write-PersistScript) }
        Update-PersistButton

        Load-Adapters -UseSavedOrder

        if ($errors.Count -gt 0) { Set-Status "$(T 'ApplyErr') $($errors -join ' | ')" }
        else { Set-Status "$(T 'Applied') ($(Get-Date -Format 'HH:mm:ss'))" }
    } catch {
        Write-AppLog "Apply click error: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("$(T 'ErrApply') $($_.Exception.Message)", (T "ErrTitle")) | Out-Null
    }
})

$ctrl.RestoreBtn.Add_Click({
    try {
        if (-not (Test-Path $BackupFile)) { Set-Status (T "NoBackup"); return }
        $backup = Get-Content $BackupFile -Raw | ConvertFrom-Json
        $errors = @()
        foreach ($b in $backup) {
            try {
                if ($null -ne $b.MetricV4) {
                    if ($b.AutoMetricV4 -eq "Enabled") {
                        Set-NetIPInterface -InterfaceIndex $b.IfIndex -AddressFamily IPv4 -AutomaticMetric Enabled -ErrorAction Stop | Out-Null
                    } else {
                        Set-NetIPInterface -InterfaceIndex $b.IfIndex -AddressFamily IPv4 -InterfaceMetric $b.MetricV4 -AutomaticMetric Disabled -ErrorAction Stop | Out-Null
                    }
                }
                # IPv6 is intentionally left untouched - this tool only manages IPv4.
            } catch { $errors += "$($b.Name): $($_.Exception.Message)" }
        }

        if (Test-Path $OrderFile) { Remove-Item $OrderFile -Force -ErrorAction SilentlyContinue }
        if (Test-Path $PlanFile)  { Remove-Item $PlanFile  -Force -ErrorAction SilentlyContinue }
        [void](Disable-Persist)
        Update-PersistButton
        Load-Adapters

        if ($errors.Count -gt 0) { Set-Status "$(T 'RestoreErr') $($errors -join ' | ')" }
        else { Set-Status (T "Restored") }
    } catch {
        Write-AppLog "Restore click error: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("$(T 'ErrRestore') $($_.Exception.Message)", (T "ErrTitle")) | Out-Null
    }
})

$ctrl.RefreshBtn.Add_Click({
    try { Load-Adapters -UseSavedOrder; Set-Status (T "Refreshed") }
    catch { Write-AppLog "Refresh click error: $($_.Exception.Message)" }
})

# ===================== System Tray =====================
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
try {
    if (Test-Path $IconFile) { $notifyIcon.Icon = New-Object System.Drawing.Icon($IconFile) }
    else { $notifyIcon.Icon = [System.Drawing.SystemIcons]::Shield }
} catch {
    Write-AppLog "Tray icon load failed: $($_.Exception.Message)"
    $notifyIcon.Icon = [System.Drawing.SystemIcons]::Shield
}
$notifyIcon.Text = "Network Priority Manager"
$notifyIcon.Visible = $false

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$showItem = $menu.Items.Add((T "TrayShow"))
$exitItem = $menu.Items.Add((T "TrayExit"))
$notifyIcon.ContextMenuStrip = $menu

$script:AllowClose = $false

function Minimize-ToTray {
    $window.Hide()
    $notifyIcon.Visible = $true
    $notifyIcon.ShowBalloonTip(1500, "Network Priority Manager", (T "TrayRunning"), [System.Windows.Forms.ToolTipIcon]::Info)
}
function Restore-FromTray {
    $window.Show()
    $window.WindowState = 'Normal'
    $window.Activate()
    $notifyIcon.Visible = $false
}

$ctrl.TrayBtn.Add_Click({ Minimize-ToTray })
$notifyIcon.Add_MouseDoubleClick({ Restore-FromTray })
$showItem.Add_Click({ Restore-FromTray })
$exitItem.Add_Click({
    $script:AllowClose = $true
    $notifyIcon.Visible = $false
    $window.Close()
})

$window.Add_Closing({
    param($s, $e)
    # Closing the window (X button or Exit) always fully exits the app now.
    # Only the "Minimize to tray" button (which calls Minimize-ToTray / Hide()
    # directly) sends the app to the tray - these two are fully separate.
    $notifyIcon.Visible = $false
})

# ===================== Startup =====================
function Apply-Language {
    try {
        $window.Title            = T "AppTitle"
        $ctrl.HeaderSub.Text     = T "HeaderSub"
        $ctrl.HelpBtn.Content    = T "Help"
        $ctrl.AboutBtn.Content   = T "About"
        $ctrl.LangBtn.Content    = T "LangBtn"
        $ctrl.LangBtn.ToolTip    = T "LangTip"
        $ctrl.SubtitleText.Text  = T "Subtitle"
        $ctrl.ApplyBtn.Content   = T "Apply"
        $ctrl.RefreshBtn.Content = T "Refresh"
        $ctrl.RestoreBtn.Content = T "Restore"
        $ctrl.TrayBtn.Content    = T "Tray"
        try { Update-PersistButton } catch {}
        try { $showItem.Text = T "TrayShow"; $exitItem.Text = T "TrayExit" } catch {}
        try { $notifyIcon.Text = T "AppTitle" } catch {}

        # Keep the title bar and adapter list left-to-right (adapter names are latin)
        try {
            $ctrl.TitleBar.FlowDirection = [System.Windows.FlowDirection]::LeftToRight
            $ctrl.AdapterList.FlowDirection = [System.Windows.FlowDirection]::LeftToRight
        } catch {}
        if (Is-RTL) {
            $window.FlowDirection = [System.Windows.FlowDirection]::RightToLeft
            $window.FontFamily = New-Object System.Windows.Media.FontFamily "Segoe UI, Tahoma"
        } else {
            $window.FlowDirection = [System.Windows.FlowDirection]::LeftToRight
            $window.FontFamily = New-Object System.Windows.Media.FontFamily "Segoe UI"
        }
    } catch { Write-AppLog "Apply-Language: $($_.Exception.Message)" }
}

function Switch-Language {
    try {
        $script:Lang = if (Is-RTL) { "EN" } else { "FA" }
        try { Set-Content -Path $LangFile -Value $script:Lang -Encoding UTF8 } catch {}
        Apply-Language
        Load-Adapters -UseSavedOrder
        Set-Status (T "LangChanged")
    } catch { Write-AppLog "Switch-Language: $($_.Exception.ToString())" }
}

Apply-Language

$ctrl.HelpBtn.Add_Click({ Show-HelpDialog })
$ctrl.LangBtn.Add_Click({ Switch-Language })

$ctrl.AboutBtn.Add_Click({
    Show-CustomDialog -Title (T "About") -Subtitle (T "AboutSub") -Body (T "AboutText") -WithLink
})


Load-Adapters -UseSavedOrder
Update-PersistButton
Set-Status (T "Ready")

$script:StatusTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:StatusTimer.Interval = [TimeSpan]::FromSeconds(4)
$script:StatusTimer.Add_Tick({ Sync-AdapterList })
$script:StatusTimer.Start()

$window.Add_Closed({
    try { $script:StatusTimer.Stop() } catch {}
    try { $window.Dispatcher.InvokeShutdown() } catch {}
})

if (-not $window) {
    Show-FatalError "Error building the window" "The app window is not available."
    exit 1
}
try {
    # IMPORTANT: ShowDialog() pushes a modal message loop that ends the whole
    # app as soon as the window is Hide()-den (which is exactly what
    # "Minimize to tray" does) - that was the cause of the app closing
    # instead of minimizing. Show() + Dispatcher.Run() keeps a normal message
    # loop running so Hide()/Show() work like a real tray app.
    $window.Show()
    [System.Windows.Threading.Dispatcher]::Run()
} catch {
    Write-AppLog ("Dispatcher.Run error: " + $_.Exception.ToString() + " | " + $_.ScriptStackTrace)
    throw
}
try { if ($notifyIcon) { $notifyIcon.Dispose() } } catch {}

} catch {
    Show-FatalError "Application runtime error" $_.Exception.Message $_
    exit 1
}
