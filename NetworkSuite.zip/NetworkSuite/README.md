# Network Priority Manager

A small tool that sets Windows' **Interface Metric** for your physical network adapters, so you can pick which one is the default internet connection.

## Run it

Double-click `NetworkSuite.exe` (no console window). Accept the UAC prompt.
If it doesn't open, run `NetworkSuite_Debug.bat` to see the error text. Error log:
`%TEMP%\NetworkSuite_error.log`

> **Note:** `NetworkSuite.exe` isn't code-signed, so Windows SmartScreen/Defender may
> show an "unrecognized app" warning the first time you run it. Click **More info → Run anyway**.

## How it works

- Every physical adapter is shown with a live status (green = connected, red = disconnected) and its current Metric.
- **Drag and drop** to reorder; top row = default internet.
- **Apply**: sets the Windows Interface Metric to 10, 20, 30, … in that order, and disables Automatic Metric so Windows can't silently recalculate and override it later. (This was the cause of "the priority I set doesn't actually work" in earlier versions.)
- **Restore previous settings**: reverts to the original values (backed up automatically on the first Apply).
- Status refreshes automatically every 4 seconds, and a Tray notification tells you when a new adapter is plugged in.
- **Minimize to tray**: the app keeps running in the System Tray, using your custom icon (`icon.ico`).
- **Closing the window** (the X button, or Exit from the tray menu) fully quits the app — it's completely separate from "Minimize to tray".

## Notes

- Settings are stored under `%APPDATA%\NetworkSuite\` (`order.json`, `backup.json`).
- The app supports English and Persian (toggle button in the header).
- `icon.ico` must stay in the same folder as `NetworkSuite.exe` and `NetworkSuite.ps1` — it's used for the window icon, the taskbar icon, and the tray icon. If it's missing, the app still runs fine, just with Windows' default icon.

## Files

| File | Role |
|---|---|
| `NetworkSuite.ps1` | The whole app |
| `NetworkSuite.exe` | Launcher with the custom icon — double-click it |
| `icon.ico` | App icon used for the window, taskbar, and tray |
| `NetworkSuite_Debug.bat` | Troubleshooting run that shows errors |

