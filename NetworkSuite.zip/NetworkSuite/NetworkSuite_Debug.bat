@echo off
REM Network Suite - Debug Launcher
REM Use this if the app doesn't open normally - it keeps the console open so you can see the real error.

cd /d "%~dp0"
echo Running Network Suite ...
echo.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0NetworkSuite.ps1"
echo.
echo ------------------------------------------------------
echo If no error was shown above but the app window still did not open,
echo check this log file:
echo %TEMP%\NetworkSuite_error.log
echo ------------------------------------------------------
pause
